/* 
 * File:   calc.h
 * Author: prog
 *
 * Created on 1 de agosto de 2017, 10:14
 */

#ifndef CALC_H
#define	CALC_H

#ifdef	__cplusplus
extern "C" {
#endif
    int cal(int x, int y){
        return(x * y);
    
    
    
    }


#ifdef	__cplusplus
}
#endif

#endif	/* CALC_H */


