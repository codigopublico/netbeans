/* 
 * File:   main.cpp
 * Author: prog
 *
 * Created on 1 de agosto de 2017, 13:45
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int cont = 100;
    do
    {
        cont--;
        std::cout << "Voy por el numero cuidado no perderse  " << cont << "\n ";
    
    
    }while(cont > 0);

    return 0;
}

