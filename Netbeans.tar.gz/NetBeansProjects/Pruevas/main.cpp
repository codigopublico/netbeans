/* 
 * File:   main.cpp
 * Author: prog
 *
 * Created on 2 de agosto de 2017, 17:43
 */

#include <cstdlib>
#include <string>
#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    //este fichero es donde se haran todas las pruevas de codigo de modo que se regusitara un poco raro.
    string str;
    std::cin >> str;
    std::cout << str << "\n";
    char r[] = "hol";
    std::cout << r;
    return 0;
    //Prueva de bucles con caracteres ....
    char vocales[] = "aeiou";
    char l[] = "a";
    /* for(int i = 0; i < 4; i++ ){
        if (l == vocal[i]){
            break;
            std::cout << "Es una vocal";
        }
    }*/ //falta saber como se opera con caracteres.
    
}

