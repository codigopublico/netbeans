/* 
 * File:   main.cpp
 * Author: prog
 *
 * Created on 1 de agosto de 2017, 9:31
 */

#include <cstdlib>
#include <iostream>

using namespace std;


/*
 * 
 */
int main(int argc, char** argv) {
std::cout<< "what is 89 + 5";
            std::cout << "what is sum " ;
            return 0;
}

