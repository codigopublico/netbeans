/*
 * Calculadora.cpp
 *
 *  Created on: 10/11/2014
 *      Author: PROGRAMACION
 */

#include "Calculadora.h"

Calculadora::Calculadora() {
	// TODO Auto-generated constructor stub

}

Calculadora::~Calculadora() {
	// TODO Auto-generated destructor stub
}

int Calculadora::sumar(int a, int b)
{
	return a + b;
}

int Calculadora::restar(int a, int b){
	return a - b;
}

