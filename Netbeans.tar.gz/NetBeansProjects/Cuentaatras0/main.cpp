/* 
 * File:   main.cpp
 * Author: prog
 *
 * Created on 1 de agosto de 2017, 13:42
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int cont = 100;
    while (cont > 0)
    {
        cont--;
        std::cout << "Cuidado no descontarse, voy por la iteracion numero ... " << cont << "\n";
        
    
    
    }

    return 0;
}

