#include <iostream>

using namespace std;
int main()
{

	cout << "Bienvenid@ al curso de C++"  << endl;

	return 0;
}
