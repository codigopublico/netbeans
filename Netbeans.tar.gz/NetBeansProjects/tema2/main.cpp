/* 
 * File:   main.cpp
 * Author: prog
 *
 * Created on 31 de julio de 2017, 17:31
 */

#include <cstdlib>
#include <iostream>
#include "Calculadora.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    std::cout << "Hola mundo desde main";
    return 0;
}

