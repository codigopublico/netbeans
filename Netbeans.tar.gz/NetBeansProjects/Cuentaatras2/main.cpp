/* 
 * File:   main.cpp
 * Author: prog
 *
 * Created on 1 de agosto de 2017, 13:50
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    for (int cont = 100; cont >= 0; cont--){
        std::cout <<  "Esto es un bucle for " << cont  <<"\n";
    
    }
    std::cout << "Termine de contar";
    return 0;
}

