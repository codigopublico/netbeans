/* 
 * File:   main.cpp
 * Author: prog
 *
 * Created on 1 de agosto de 2017, 13:12
 */

#include <cstdlib>
#include <iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int conta = 100;
    while (conta > 0)
    {
        conta--;
        std::cout << "No lanzare bolitas de papel al profsor  " << conta << "\n" ; 
    
    }
    return 0;
}

